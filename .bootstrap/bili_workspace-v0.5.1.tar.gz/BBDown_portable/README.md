# Windows 外部工具目录

真实工具约定位置：

```text
BBDown_portable/BBDown.exe
BBDown_portable/ffmpeg/bin/ffmpeg.exe
```

登录后生成：

```text
BBDown_portable/BBDown.data
```

`BBDown.data` 含 Bilibili 会话，始终保持未跟踪状态，不得提交、截图或公开备份。

## Git 更新

当前源码初始提交不包含 Windows EXE。已有完整安装目录中的 EXE 被 `.gitignore` 排除，执行 `git pull` 或 `update.bat` 时会保留；`verify.bat` 在检测到工具后仍会实际启动它们。

`.gitattributes` 已为 EXE 预留 Git LFS 规则。只有真实 LFS 对象已经上传并验证时才应启用，不能只提交指针文件。

## 已验证哈希

V0.5.0 Windows 完整包使用：

```text
BBDown.exe
SHA-256 eb8b985af07c4757fa695204283208aee879bf79f6462a1d161e3a55b5a19cb1

ffmpeg.exe
SHA-256 a25942892c8e5180c2998f9936f56e914cece03708b93e8d54f38d23304dcf8c
```

放入工具后运行 `verify.bat`。纯源码克隆没有工具时，Python、Ruff、测试和前端检查仍可执行；真实下载、混流和扫码登录需要工具或 Docker 环境。
